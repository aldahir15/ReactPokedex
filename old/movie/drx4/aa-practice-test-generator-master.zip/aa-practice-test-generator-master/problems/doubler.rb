# Write a method that doubles each element in an array
def doubler(array)
end
