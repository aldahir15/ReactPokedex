# Write a method that returns the factors of a number in ascending order.

def factors(num)

end
