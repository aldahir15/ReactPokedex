# Write a recursive method that returns the sum of all elements in an array
def rec_sum(nums)
end
