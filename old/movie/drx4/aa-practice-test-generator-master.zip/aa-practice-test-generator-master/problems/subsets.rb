#returns all subsets of an array
def subsets(array)

end
