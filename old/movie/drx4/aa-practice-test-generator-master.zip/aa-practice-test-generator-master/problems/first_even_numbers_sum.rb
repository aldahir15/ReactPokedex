# return the sum of the first n even numbers recursively. Assume n > 0
def first_even_numbers_sum(n)

end
