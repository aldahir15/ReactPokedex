class Array
  def bubble_sort!(&prc)
  end

  def bubble_sort(&prc)
  end
end
