# return b^n recursively. Your solution should accept negative values
# for n
def exponent(b, n)

end
