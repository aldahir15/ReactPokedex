def doubler(array)
  array.map { |num| num * 2 }
end
